module.exports = {
    default: {
        src: [
            '<%= yeoman.src %>/**/*.js',
            '<%= yeoman.dist %>/**/!(*.min).js'
        ]
    }
};
